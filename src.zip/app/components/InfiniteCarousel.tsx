import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { CarouselCard } from './CarouselCard';
import { DetailModal } from './DetailModal';

interface CarouselItem {
  id: number;
  title: string;
  image: string;
  description: string;
  author: string;
}

interface InfiniteCarouselProps {
  items: CarouselItem[];
}

export function InfiniteCarousel({ items }: InfiniteCarouselProps) {
  const [isPaused, setIsPaused] = useState(false);
  const [selectedItem, setSelectedItem] = useState<CarouselItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Duplicamos los items para crear el efecto infinito
  const duplicatedItems = [...items, ...items, ...items];

  const handleCardClick = (item: CarouselItem) => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedItem(null), 300);
  };

  return (
    <>
      <div
        className="relative overflow-hidden py-8"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        <motion.div
          className="flex gap-6"
          animate={{
            x: [0, -(items.length * 320)],
          }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: "loop",
              duration: items.length * 5,
              ease: "linear",
            },
          }}
          style={{
            animationPlayState: isPaused ? 'paused' : 'running',
          }}
        >
          {duplicatedItems.map((item, index) => (
            <CarouselCard
              key={`${item.id}-${index}`}
              item={item}
              onClick={() => handleCardClick(item)}
            />
          ))}
        </motion.div>

        {/* Gradientes en los bordes */}
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-slate-50 to-transparent pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-blue-50 to-transparent pointer-events-none" />
      </div>

      <DetailModal
        item={selectedItem}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </>
  );
}
