import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CarouselItem {
  id: number;
  title: string;
  image: string;
  description: string;
  author: string;
}

interface CarouselCardProps {
  item: CarouselItem;
  onClick: () => void;
}

export function CarouselCard({ item, onClick }: CarouselCardProps) {
  return (
    <motion.div
      className="flex-shrink-0 w-72 cursor-pointer"
      whileHover={{ scale: 1.05, y: -8 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      onClick={onClick}
    >
      <div className="bg-white rounded-xl shadow-lg overflow-hidden h-full hover:shadow-2xl transition-shadow duration-300">
        <div className="relative h-48 overflow-hidden bg-slate-100">
          <ImageWithFallback
            src={item.image}
            alt={item.title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
        </div>

        <div className="p-5">
          <h3 className="text-slate-800 mb-2 line-clamp-2">
            {item.title}
          </h3>
          <p className="text-slate-500 text-sm line-clamp-2">
            {item.description}
          </p>

          <div className="mt-4 pt-4 border-t border-slate-100">
            <p className="text-xs text-slate-400">
              Foto de {item.author}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
