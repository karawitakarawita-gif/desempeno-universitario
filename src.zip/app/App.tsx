import { useState } from 'react';
import { InfiniteCarousel } from './components/InfiniteCarousel';

export default function App() {
  const carouselItems = [
    {
      id: 1,
      title: "Biblioteca Clásica",
      image: "https://images.unsplash.com/photo-1542725752-e9f7259b3881?w=600",
      description: "Colección de textos fundamentales que han dado forma al pensamiento académico occidental. Incluye obras de filosofía, literatura y ciencias sociales que siguen siendo relevantes en la educación moderna.",
      author: "Viktor Talashuk"
    },
    {
      id: 2,
      title: "Archivo Histórico",
      image: "https://images.unsplash.com/photo-1662304696102-efafa11b27c3?w=600",
      description: "Documentos y manuscritos preservados que ofrecen una ventana al pasado. Estos recursos son esenciales para la investigación histórica y el análisis de la evolución del conocimiento.",
      author: "Debby Hudson"
    },
    {
      id: 3,
      title: "Textos Antiguos",
      image: "https://images.unsplash.com/photo-1760840415479-438f61268bed?w=600",
      description: "Páginas amarillentas que guardan sabiduría ancestral. El estudio de estos textos permite comprender el desarrollo del pensamiento humano a través de los siglos.",
      author: "byVlado"
    },
    {
      id: 4,
      title: "Logros Académicos",
      image: "https://images.unsplash.com/photo-1577036056967-aec1101ab9de?w=600",
      description: "Celebración del esfuerzo y dedicación en el camino educativo. Representa el culminar de años de estudio, investigación y crecimiento intelectual.",
      author: "Clay Banks"
    },
    {
      id: 5,
      title: "Aprendizaje de Idiomas",
      image: "https://images.unsplash.com/photo-1543109740-4bdb38fda756?w=600",
      description: "El dominio de nuevas lenguas abre puertas a diferentes culturas y formas de pensamiento. Un recurso fundamental en la educación global contemporánea.",
      author: "Ivan Shilov"
    },
    {
      id: 6,
      title: "Estudios Profundos",
      image: "https://images.unsplash.com/photo-1760840414854-36cd365d14f1?w=600",
      description: "La inmersión en textos especializados permite desarrollar un conocimiento profundo y matizado de cualquier disciplina académica.",
      author: "byVlado"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="mb-4 text-slate-800">Recursos Académicos</h1>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Explora nuestra colección de materiales educativos. Haz clic en cualquier tarjeta para descubrir más detalles.
          </p>
        </div>

        <InfiniteCarousel items={carouselItems} />
      </div>
    </div>
  );
}
