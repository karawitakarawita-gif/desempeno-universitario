import * as Dialog from '@radix-ui/react-dialog';
import { motion, AnimatePresence } from 'motion/react';
import { X, BookOpen, User } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CarouselItem {
  id: number;
  title: string;
  image: string;
  description: string;
  author: string;
}

interface DetailModalProps {
  item: CarouselItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export function DetailModal({ item, isOpen, onClose }: DetailModalProps) {
  if (!item) return null;

  return (
    <Dialog.Root open={isOpen} onOpenChange={onClose}>
      <AnimatePresence>
        {isOpen && (
          <Dialog.Portal forceMount>
            <Dialog.Overlay asChild>
              <motion.div
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              />
            </Dialog.Overlay>

            <Dialog.Content asChild>
              <motion.div
                className="fixed top-1/2 left-1/2 z-50 w-full max-w-2xl max-h-[85vh] overflow-y-auto"
                initial={{ opacity: 0, scale: 0.95, x: "-50%", y: "-50%" }}
                animate={{ opacity: 1, scale: 1, x: "-50%", y: "-50%" }}
                exit={{ opacity: 0, scale: 0.95, x: "-50%", y: "-50%" }}
                transition={{ type: "spring", duration: 0.3 }}
              >
                <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
                  {/* Imagen del encabezado */}
                  <div className="relative h-80 overflow-hidden bg-slate-100">
                    <ImageWithFallback
                      src={item.image.replace('w=600', 'w=1200')}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />

                    {/* Título sobre la imagen */}
                    <div className="absolute bottom-0 left-0 right-0 p-8">
                      <Dialog.Title className="text-white mb-2">
                        {item.title}
                      </Dialog.Title>
                    </div>

                    {/* Botón de cerrar */}
                    <Dialog.Close asChild>
                      <button
                        className="absolute top-4 right-4 p-2 rounded-full bg-white/90 hover:bg-white transition-colors shadow-lg"
                        aria-label="Cerrar"
                      >
                        <X className="w-5 h-5 text-slate-700" />
                      </button>
                    </Dialog.Close>
                  </div>

                  {/* Contenido del modal */}
                  <div className="p-8">
                    <div className="flex items-center gap-2 mb-6 text-slate-600">
                      <BookOpen className="w-5 h-5" />
                      <span className="text-sm">Recurso Académico</span>
                    </div>

                    <Dialog.Description className="text-slate-700 leading-relaxed mb-6">
                      {item.description}
                    </Dialog.Description>

                    <div className="border-t border-slate-200 pt-6 mt-6">
                      <div className="flex items-center gap-3 text-slate-600">
                        <User className="w-5 h-5" />
                        <div>
                          <p className="text-sm">Fotografía de</p>
                          <p className="text-slate-800">{item.author}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-100">
                      <p className="text-sm text-blue-900">
                        <span className="font-medium">Nota:</span> Este recurso está disponible para consulta académica.
                        Para más información sobre cómo acceder a estos materiales, contacta con el departamento de recursos educativos.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </Dialog.Content>
          </Dialog.Portal>
        )}
      </AnimatePresence>
    </Dialog.Root>
  );
}
